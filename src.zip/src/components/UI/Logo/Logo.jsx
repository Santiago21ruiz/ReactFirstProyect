import React from 'react'
import ftReact from '../../../images/ftReact.jpg';

export const Logo = () => {
  return (
    <img src={ftReact} alt="LogoTipi" className='ftReact'/>
  )
}
